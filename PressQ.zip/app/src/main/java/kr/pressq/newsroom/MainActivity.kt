package kr.pressq.newsroom

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.net.HttpURLConnection
import java.net.URL
import org.jsoup.Jsoup
import java.util.concurrent.TimeUnit

data class PressItem(
    val title: String, val link: String, val date: String, val source: String,
    val body: String = "", val imageUrls: String = ""
)

class MainActivity : AppCompatActivity() {
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private var intervalSpinnerReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
        }

        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)

        val purple = 0xff5426a8.toInt()
        val deepPurple = 0xff35136f.toInt()
        val ink = 0xff211b2b.toInt()
        val muted = 0xff777181.toInt()
        val canvas = 0xfff7f5fb.toInt()
        val lilac = 0xfff0eafb.toInt()
        val line = 0xffe9e3f0.toInt()
        val wide = resources.configuration.screenWidthDp >= 600
        val density = resources.displayMetrics.density
        fun dp(v: Int) = (v * density).toInt()

        fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
            TextView(this).apply {
                this.text = value
                textSize = size
                setTextColor(color)
                if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
                includeFontPadding = true
            }

        fun rounded(color: Int, stroke: Int = 0x00000000, radius: Int = 20): android.graphics.drawable.GradientDrawable =
            android.graphics.drawable.GradientDrawable().apply {
                setColor(color)
                cornerRadius = dp(radius).toFloat()
                if (stroke != 0x00000000) setStroke(dp(1), stroke)
            }

        fun verticalCard(padding: Int = 18): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(padding), dp(padding), dp(padding), dp(padding))
            background = rounded(android.graphics.Color.WHITE, line, 22)
            elevation = dp(1).toFloat()
        }

        fun pill(label: String, bg: Int, fg: Int): TextView = text(label, 11f, fg, true).apply {
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = rounded(bg, radius = 30)
        }

        fun button(label: String, primary: Boolean = false, action: () -> Unit): TextView =
            text(label, 14f, if (primary) android.graphics.Color.WHITE else purple, true).apply {
                gravity = android.view.Gravity.CENTER
                minHeight = dp(48)
                setPadding(dp(14), dp(10), dp(14), dp(10))
                background = rounded(if (primary) purple else lilac, radius = 14)
                isClickable = true
                isFocusable = true
                setOnClickListener { action() }
            }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(canvas)
            clipToPadding = false
        }
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(
                androidx.core.view.WindowInsetsCompat.Type.systemBars() or
                    androidx.core.view.WindowInsetsCompat.Type.displayCutout()
            )
            view.setPadding(dp(if (wide) 28 else 18), bars.top + dp(8), dp(if (wide) 28 else 18), bars.bottom)
            insets
        }

        val scroll = ScrollView(this).apply {
            clipToPadding = false
            isFillViewport = true
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(24))
        }

        // Brand header
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(8))
        }
        val brandMark = TextView(this).apply {
            text = "Q"
            textSize = 24f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(android.graphics.Color.WHITE)
            gravity = android.view.Gravity.CENTER
            background = rounded(purple, radius = 16)
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
        }
        val menuButton = TextView(this).apply {
            text = "☰"
            textSize = 23f
            setTextColor(ink)
            gravity = android.view.Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(42), dp(48))
            setOnClickListener { showDrawer(root, dp(280)) }
        }
        header.addView(menuButton)
        header.addView(brandMark)
        val brandText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
            addView(text("PressQ", 23f, ink, true))
            addView(text("NEWSROOM", 10f, muted, true))
        }
        header.addView(brandText, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(header, LinearLayout.LayoutParams(-1, -2))

        // Welcome / hero panel
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(16))
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                intArrayOf(deepPurple, purple, 0xff7650c5.toInt())
            ).apply { cornerRadius = dp(24).toFloat() }
        }
        hero.addView(text("오늘의 정책·의정 자료", 19f, android.graphics.Color.WHITE, true))
        hero.addView(text("기관별 새 자료를 확인하고 필요한 내용만 살펴보세요.", 11f, 0xffeee7fb.toInt()).apply {
            setPadding(0, dp(5), 0, 0)
        })
        val heroActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(18), 0, 0)
        }
        val collectNow = TextView(this).apply {
            text = "지금 수집  ↗"
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(deepPurple)
            gravity = android.view.Gravity.CENTER
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = rounded(android.graphics.Color.WHITE, radius = 14)
            setOnClickListener { refresh() }
        }
        heroActions.addView(collectNow, LinearLayout.LayoutParams(-2, dp(46)))

        hero.addView(heroActions)
        content.addView(hero, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })

        // Compact collection status
        status = text("수집 확인 중", 11f, muted)
        val statusRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(dp(2), dp(10), dp(2), dp(12))
            addView(text("수집 상태", 13f, ink, true), LinearLayout.LayoutParams(0, -2, 1f))
            addView(status.apply { textSize = 11f; setTextColor(muted) })
        }
        content.addView(statusRow)

        // Recent materials
        val recentHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            addView(text("최근 수집 자료", 17f, ink, true), LinearLayout.LayoutParams(0, -2, 1f))
            addView(text("최신순", 11f, muted, true))
        }
        content.addView(recentHeader, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)

        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        // Compact bottom navigation
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(android.graphics.Color.WHITE)
                setStroke(dp(1), line)
            }
        }
        fun nav(label: String, selected: Boolean, action: () -> Unit) = TextView(this).apply {
            text = label
            textSize = 11f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(if (selected) purple else muted)
            gravity = android.view.Gravity.CENTER
            setPadding(dp(6), dp(8), dp(6), dp(8))
            setOnClickListener { action() }
        }
        bottom.addView(nav("⌂  홈", true) { scroll.smoothScrollTo(0, 0) }, LinearLayout.LayoutParams(0, dp(44), 1f))
        bottom.addView(nav("▤  자료", false) { scroll.post { scroll.smoothScrollTo(0, recentHeader.top) } }, LinearLayout.LayoutParams(0, dp(44), 1f))
        bottom.addView(nav("✎  기사", false) { showDrafts() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        bottom.addView(nav("⚙  설정", false) { showSettings() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        root.addView(bottom)

        setContentView(root)
        schedule()
        refresh()
    }

    private fun editCmsCredentials() {
        val saved = CmsCredentialStore.read(this)
        val idInput = EditText(this).apply {
            hint = "CMS 아이디"
            setText(saved.first)
            isSingleLine = true
        }
        val pwInput = EditText(this).apply {
            hint = "CMS 비밀번호"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(saved.second)
            isSingleLine = true
        }
        val remember = CheckBox(this).apply {
            text = "이 기기에 로그인 정보 암호화 저장"
            isChecked = saved.first.isNotBlank() && saved.second.isNotBlank()
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 8, 32, 0)
            addView(idInput)
            addView(pwInput)
            addView(remember)
            addView(TextView(this@MainActivity).apply {
                text = "정보는 이 휴대폰 안에서 암호화해 보관합니다. 앱 삭제 또는 데이터 초기화 시 저장 정보가 사라질 수 있습니다."
                textSize = 12f
            })
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("PressQ CMS 로그인 설정")
            .setView(panel)
            .setNegativeButton("취소", null)
            .setNeutralButton("저장정보 삭제") { _, _ -> CmsCredentialStore.clear(this) }
            .setPositiveButton("저장") { _, _ ->
                if (remember.isChecked && idInput.text.isNotBlank() && pwInput.text.isNotBlank()) {
                    CmsCredentialStore.write(this, idInput.text.toString(), pwInput.text.toString())
                    Toast.makeText(this, "CMS 로그인 정보를 암호화해 저장했습니다.", Toast.LENGTH_LONG).show()
                } else {
                    CmsCredentialStore.clear(this)
                    Toast.makeText(this, "저장 정보를 삭제했습니다.", Toast.LENGTH_LONG).show()
                }
            }.show()
    }

    private fun openCms() {
        val creds = CmsCredentialStore.read(this)
        if (creds.first.isBlank() || creds.second.isBlank()) {
            Toast.makeText(this, "먼저 CMS 로그인 정보를 설정해 주세요.", Toast.LENGTH_LONG).show()
            editCmsCredentials()
            return
        }
        startActivity(android.content.Intent(this, CmsLoginActivity::class.java))
    }

    private fun schedule() {
        val minutes = getSharedPreferences("pressq_settings", Context.MODE_PRIVATE)
            .getInt("interval_minutes", 15).coerceIn(15, 120)
        val request = PeriodicWorkRequestBuilder<PressWorker>(minutes.toLong(), TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "pressq-monitor", ExistingPeriodicWorkPolicy.UPDATE, request
        )
        status.text = "자동수집 예약됨 · ${minutes}분 주기 (절전 상태에 따라 지연 가능)"
    }

    private fun refresh() {
        status.text = "서울시 공식 RSS 확인 중…"
        Thread {
            try {
                val fetched = PressFetcher.fetchSeoul() + PressFetcher.fetchCouncilRss()
                val archived = fetched.map { MediaArchive.downloadImages(this, it) }
                val database = PressDatabase(this)
                database.save(archived)
                val items = database.latest(30)
                runOnUiThread {
                    list.removeAllViews()
                    if (items.isEmpty()) {
                        addMessage("RSS 응답은 받았지만 표시할 게시물이 없습니다.")
                    } else {
                        items.take(30).forEach { item ->
                            val cardBox = LinearLayout(this).apply {
                                orientation = LinearLayout.VERTICAL
                                setPadding(dp(14), dp(12), dp(14), dp(12))
                                background = rounded(android.graphics.Color.WHITE, line, 16)
                                isClickable = true
                                isFocusable = true
                                setOnClickListener { showMaterialDetail(item) }
                            }
                            cardBox.addView(text("${item.source}  ·  ${item.date}", 11f, purple, true))
                            cardBox.addView(text(item.title, 15f, ink, true).apply {
                                setPadding(0, dp(5), 0, dp(4))
                                maxLines = 2
                                ellipsize = android.text.TextUtils.TruncateAt.END
                            })
                            val summary = item.body.replace(Regex("\\s+"), " ").trim()
                            if (summary.isNotBlank()) cardBox.addView(text(summary.take(82) + if (summary.length > 82) "…" else "", 11f, muted).apply {
                                maxLines = 2
                            })
                            list.addView(cardBox, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
                        }
                    }
                    status.text = "휴대폰 저장 자료 ${items.size}건 · 서울시 및 시의회 확인 완료"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    list.removeAllViews()
                    addMessage("수집 실패: ${e.localizedMessage ?: "네트워크 또는 피드 응답 오류"}")
                    status.text = "수집에 실패했습니다."
                }
            }
        }.start()
    }

    private fun showDrawer(anchor: android.view.View, drawerWidth: Int) {
        val density = resources.displayMetrics.density
        fun dp(value: Int) = (value * density).toInt()
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(16), dp(16))
            setBackgroundColor(android.graphics.Color.WHITE)
        }
        panel.addView(TextView(this).apply {
            text = "PressQ  NEWSROOM"
            textSize = 20f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(0xff5426a8.toInt())
            setPadding(0, 0, 0, dp(22))
        })
        val popup = android.widget.PopupWindow(panel, drawerWidth, -1, true).apply {
            elevation = dp(12).toFloat()
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(android.graphics.Color.WHITE))
            isOutsideTouchable = true
        }
        fun entry(label: String, action: () -> Unit) {
            panel.addView(TextView(this).apply {
                text = label
                textSize = 15f
                setTextColor(0xff30283a.toInt())
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(0, dp(14), 0, dp(14))
                setOnClickListener { popup.dismiss(); action() }
            })
        }
        entry("뉴스룸 홈") { recreate() }
        entry("전체 수집 자료") { }
        entry("서울특별시 자료") { Toast.makeText(this, "서울특별시 자료는 기관별로 구분해 표시합니다.", Toast.LENGTH_SHORT).show() }
        entry("서울특별시의회 자료") { Toast.makeText(this, "서울특별시의회 자료는 기관별로 구분해 표시합니다.", Toast.LENGTH_SHORT).show() }
        entry("기사 작업실") { showDrafts() }
        entry("CMS 연결 설정") { editCmsCredentials() }
        entry("마이페이지") { Toast.makeText(this, "로그인 기능은 추후 연결할 수 있도록 준비 중입니다.", Toast.LENGTH_SHORT).show() }
        popup.showAtLocation(anchor, android.view.Gravity.START or android.view.Gravity.TOP, 0, 0)
        panel.startAnimation(android.view.animation.TranslateAnimation(-drawerWidth.toFloat(), 0f, 0f, 0f).apply { duration = 180 })
    }

    private fun showDrafts() {
        val folder = java.io.File(filesDir, "drafts")
        val files = folder.listFiles()?.sortedByDescending { it.lastModified() }.orEmpty()
        if (files.isEmpty()) {
            android.app.AlertDialog.Builder(this).setTitle("기사 작업실")
                .setMessage("저장된 기사 초안이 없습니다. 수집 자료를 열고 ‘기사 초안’을 선택해 주세요.")
                .setPositiveButton("확인", null).show()
            return
        }
        val names = files.map { it.name.substringAfter('_').removeSuffix(".txt").replace('_', ' ') }.toTypedArray()
        android.app.AlertDialog.Builder(this).setTitle("저장된 기사 초안")
            .setItems(names) { _, which ->
                val content = files[which].readText(Charsets.UTF_8)
                android.app.AlertDialog.Builder(this).setTitle(names[which])
                    .setMessage(content.take(3500)).setPositiveButton("닫기", null).show()
            }.setNegativeButton("닫기", null).show()
    }

    private fun showSettings() {
        val prefs = getSharedPreferences("pressq_settings", Context.MODE_PRIVATE)
        val choices = arrayOf("15분", "30분", "60분", "120분")
        val current = listOf(15, 30, 60, 120).indexOf(prefs.getInt("interval_minutes", 15)).coerceAtLeast(0)
        android.app.AlertDialog.Builder(this).setTitle("설정")
            .setSingleChoiceItems(choices, current) { dialog, which ->
                val minutes = listOf(15, 30, 60, 120)[which]
                prefs.edit().putInt("interval_minutes", minutes).apply()
                schedule()
                dialog.dismiss()
                Toast.makeText(this, "자동 수집 주기를 ${minutes}분으로 변경했습니다.", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("CMS 연결 설정") { _, _ -> editCmsCredentials() }
            .setNegativeButton("닫기", null).show()
    }

    private fun showMaterialDetail(item: PressItem) {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 0)
        }
        panel.addView(TextView(this).apply {
            text = "${item.source} · ${item.date}"
            textSize = 12f
            setTextColor(0xff5426a8.toInt())
        })
        panel.addView(TextView(this).apply {
            text = item.title
            textSize = 18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 10, 0, 12)
        })
        panel.addView(TextView(this).apply {
            text = item.body.ifBlank { "상세 본문을 확보하지 못했습니다. 원문 페이지에서 확인해 주세요." }
            textSize = 14f
            setTextColor(0xff393441.toInt())
            setTextIsSelectable(true)
        })
        panel.addView(TextView(this).apply {
            text = "원문 페이지 열기 ↗"
            textSize = 13f
            setTextColor(0xff5426a8.toInt())
            setPadding(0, 16, 0, 8)
            setOnClickListener { startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(item.link))) }
        })
        android.app.AlertDialog.Builder(this)
            .setView(panel)
            .setPositiveButton("닫기", null)
            .setNeutralButton("AI 초안") { _, _ -> requestAiDraft(item) }
            .setNegativeButton("기사 초안") { _, _ ->
                try {
                    val file = DraftMaker.save(this, item)
                    Toast.makeText(this, "초안 저장 완료: ${file.name}", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "초안 저장 실패: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                }
            }.show()
    }

    private fun requestAiDraft(item: PressItem) {
        val providerGroup = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val geminiRadio = RadioButton(this).apply { id = 1; text = "Gemini 무료"; isChecked = true }
        val openAiRadio = RadioButton(this).apply { id = 2; text = "OpenAI 유료" }
        providerGroup.addView(geminiRadio)
        providerGroup.addView(openAiRadio)

        val savedGeminiKey = GeminiKeyStore.read(this)
        val savedOpenAiKey = OpenAiKeyStore.read(this)
        val modelInput = EditText(this).apply {
            setText("gemini-3.8-flash")
            hint = "모델 ID"
            isSingleLine = true
        }
        val keyInput = EditText(this).apply {
            hint = "Gemini API Key"
            setText(savedGeminiKey)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val rememberKey = CheckBox(this).apply {
            text = "이 기기에 API 키 암호화 저장"
            isChecked = savedGeminiKey.isNotBlank()
        }
        val privacyNote = TextView(this).apply {
            text = "Gemini 무료 등급은 사용량 제한이 있으며 입력한 자료가 Google 제품 개선에 사용될 수 있습니다. 민감하거나 비공개인 취재자료는 입력하지 마세요. 기기 내 암호화는 파일 유출 위험을 줄이지만 루팅·디버깅·실행 중 메모리 노출까지 막지는 못합니다."
            textSize = 12f
        }
        providerGroup.setOnCheckedChangeListener { _, checkedId ->
            val isGemini = checkedId == 1
            val saved = if (isGemini) savedGeminiKey else savedOpenAiKey
            keyInput.setText(saved)
            keyInput.hint = if (isGemini) "Gemini API Key" else "OpenAI API Key"
            modelInput.setText(if (isGemini) "gemini-3.8-flash" else "gpt-6-luna")
            rememberKey.isChecked = saved.isNotBlank()
            privacyNote.text = if (isGemini) {
                "Gemini 무료 등급은 사용량 제한이 있으며 입력한 자료가 Google 제품 개선에 사용될 수 있습니다. 민감하거나 비공개인 취재자료는 입력하지 마세요. 기기 내 암호화는 파일 유출 위험을 줄이지만 루팅·디버깅·실행 중 메모리 노출까지 막지는 못합니다."
            } else {
                "OpenAI API는 ChatGPT 구독과 별도 과금입니다. 전용 프로젝트 키와 낮은 사용 한도를 권장합니다. 모바일 앱 직접 호출은 키 추출 위험이 있어 기기 내 암호화만으로 완전히 방지할 수 없습니다."
            }
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 8, 32, 0)
            addView(providerGroup)
            addView(TextView(this@MainActivity).apply { text = "모델 ID" })
            addView(modelInput)
            addView(TextView(this@MainActivity).apply { text = "API Key" })
            addView(keyInput)
            addView(rememberKey)
            addView(privacyNote)
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("AI 기사 초안 설정")
            .setView(panel)
            .setNegativeButton("취소", null)
            .setPositiveButton("작성") { _, _ ->
                val useGemini = providerGroup.checkedRadioButtonId == 1
                val model = modelInput.text.toString().trim()
                val key = keyInput.text.toString().trim()
                if (rememberKey.isChecked && key.isNotBlank()) {
                    if (useGemini) GeminiKeyStore.write(this, key) else OpenAiKeyStore.write(this, key)
                } else {
                    if (useGemini) GeminiKeyStore.clear(this) else OpenAiKeyStore.clear(this)
                }
                if (model.isBlank() || key.isBlank()) {
                    Toast.makeText(this, "모델 ID와 API Key를 입력해 주세요.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                status.text = if (useGemini) "Gemini로 기사 초안 생성 중…" else "OpenAI로 기사 초안 생성 중…"
                Thread {
                    try {
                        val result = if (useGemini) {
                            GeminiArticleWriter.generate(item, model, key)
                        } else {
                            AiArticleWriter.generate(item, model, key)
                        }
                        val file = DraftMaker.saveGenerated(this, item, result.text)
                        runOnUiThread {
                            val costLabel = when {
                                useGemini -> " · Gemini 무료 등급 요청"
                                result.costUsd != null -> " · 예상 비용 $${"%.6f".format(java.util.Locale.US, result.costUsd)}"
                                else -> " · 비용 산정 불가"
                            }
                            status.text = "AI 초안 저장 완료: ${file.name}$costLabel"
                            Toast.makeText(this,
                                "AI 초안 저장 완료\\n입력 ${result.inputTokens} tokens / 출력 ${result.outputTokens} tokens$costLabel",
                                Toast.LENGTH_LONG).show()
                        }
                    } catch (e: Exception) {
                        runOnUiThread {
                            status.text = "AI 초안 생성 실패"
                            val msg = e.localizedMessage ?: "API 요청 오류"
                            Toast.makeText(this,
                                if (useGemini) "Gemini 요청 실패(무료 한도·키·모델 확인): $msg" else msg,
                                Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
            .show()
    }

    private fun addMessage(message: String) {
        list.addView(TextView(this).apply {
            text = message
            textSize = 15f
            setPadding(12, 24, 12, 24)
        })
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(
                NotificationChannel("pressq_new", "새 보도자료", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
    }
}

object PressFetcher {
    private const val SEOUL_RSS =
        "https://seoulboard.seoul.go.kr/rss/RSSGenerator?bbsNo=158"

    fun fetchSeoul(): List<PressItem> =
        fetchRss("서울특별시", SEOUL_RSS).take(8).map { item -> fetchDetail(item) }

    private fun fetchDetail(item: PressItem): PressItem {
        val connection = (URL(item.link).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000
            readTimeout = 10000
            setRequestProperty("User-Agent", "Mozilla/5.0 PressQ-Newsroom/0.2")
        }
        return try {
            val html = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val doc = Jsoup.parse(html, item.link)
            doc.select("script,style,nav,header,footer,aside,form,button,select,option,iframe,noscript").remove()
            doc.select(".gnb, .lnb, .snb, .menu, .breadcrumb, .location, .paging, .pagination, .search, .quick, .related, .reply, .comment, .footer, .header").remove()
            val candidates = listOf(
                ".view_cont", ".board_view", ".bbs_view", ".view-content",
                ".board-view", ".article-view", "article", "main", "#content"
            )
            val body = candidates.asSequence()
                .mapNotNull { selector -> doc.selectFirst(selector)?.text()?.trim() }
                .firstOrNull { it.length > 80 }
                ?: doc.select(".view, .content, .cont, .article").maxByOrNull { it.text().length }?.text()?.trim().orEmpty()
            val cleanedBody = body.replace(Regex("\\s+"), " ").trim()
            val images = doc.select("img[src]")
                .map { it.absUrl("src") }
                .filter { it.startsWith("http") }
                .distinct()
                .take(6)
                .joinToString("\n")
            item.copy(body = cleanedBody.take(5000), imageUrls = images)
        } catch (_: Exception) {
            item
        } finally {
            connection.disconnect()
        }
    }

    // 서울시의회 공식 보도자료 RSS를 직접 수집한다.
    private const val COUNCIL_RSS =
        "https://www.smc.seoul.kr/rss/broadRss.do"

    fun fetchCouncilRss(): List<PressItem> =
        fetchRss("서울특별시의회", COUNCIL_RSS).take(8).map { item -> fetchDetail(item) }

    fun fetchRss(source: String, address: String): List<PressItem> {
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 15000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "Mozilla/5.0 PressQ-Newsroom/0.2")
            setRequestProperty("Accept", "application/rss+xml, application/xml, text/xml, */*")
        }
        return try {
            connection.inputStream.use { input ->
                val parser = XmlPullParserFactory.newInstance().newPullParser()
                parser.setInput(input, "UTF-8")
                val results = mutableListOf<PressItem>()
                var event = parser.eventType
                var inItem = false
                var title = ""
                var link = ""
                var date = ""
                var currentTag = ""

                while (event != XmlPullParser.END_DOCUMENT) {
                    when (event) {
                        XmlPullParser.START_TAG -> {
                            currentTag = parser.name.lowercase()
                            if (currentTag == "item" || currentTag == "entry") {
                                inItem = true
                                title = ""
                                link = ""
                                date = ""
                            } else if (inItem && currentTag == "link") {
                                val href = parser.getAttributeValue(null, "href")
                                if (!href.isNullOrBlank()) link = href
                            }
                        }
                        XmlPullParser.TEXT -> if (inItem) {
                            when (currentTag) {
                                "title" -> title += parser.text
                                "link" -> link += parser.text
                                "pubdate", "published", "updated", "dc:date" -> date += parser.text
                            }
                        }
                        XmlPullParser.END_TAG -> {
                            val tag = parser.name.lowercase()
                            if (inItem && (tag == "item" || tag == "entry")) {
                                if (title.isNotBlank() && link.isNotBlank()) {
                                    results.add(PressItem(Jsoup.parse(title).text().replace(Regex("\\s+"), " ").trim(), link.trim(), date.trim(), source))
                                }
                                inItem = false
                            }
                            currentTag = ""
                        }
                    }
                    event = parser.next()
                }
                results
            }
        } finally {
            connection.disconnect()
        }
    }
}

class PressWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        return try {
            val fetched = PressFetcher.fetchSeoul() + PressFetcher.fetchCouncilRss()
            val items = fetched.map { MediaArchive.downloadImages(applicationContext, it) }
            val database = PressDatabase(applicationContext)
            val newItems = database.save(items)

            if (newItems.isNotEmpty()) {
                val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                newItems.take(5).forEachIndexed { index, item ->
                    val notification = NotificationCompat.Builder(applicationContext, "pressq_new")
                        .setSmallIcon(android.R.drawable.ic_dialog_info)
                        .setContentTitle("새 서울시 보도자료")
                        .setContentText(item.title)
                        .setStyle(NotificationCompat.BigTextStyle().bigText(item.title))
                        .setAutoCancel(true)
                        .build()
                    manager.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt() + index, notification)
                }
            }
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}


data class AiDraftResult(
    val text: String,
    val inputTokens: Int,
    val outputTokens: Int,
    val costUsd: Double?
)

object AiArticleWriter {
    // Standard text-token rates per 1M tokens. Keep this aligned with OpenAI's live pricing.
    private val standardRatesUsd = mapOf(
        "gpt-6-luna" to Pair(0.10, 0.50),
        "gpt-6.1-terra" to Pair(1.00, 5.00),
        "gpt-6.1-sol" to Pair(2.00, 10.00),
        "gpt-6-astra" to Pair(10.00, 50.00)
    )

    fun estimateUsd(model: String, inputTokens: Int, outputTokens: Int): Double? {
        val rates = standardRatesUsd[model] ?: return null
        return (inputTokens * rates.first + outputTokens * rates.second) / 1_000_000.0
    }

    fun generate(item: PressItem, model: String, apiKey: String): AiDraftResult {
        val endpoint = URL("https://api.openai.com/v1/chat/completions")
        val connection = endpoint.openConnection() as HttpURLConnection
        connection.requestMethod = "POST"
        connection.connectTimeout = 20000
        connection.readTimeout = 90000
        connection.doOutput = true
        connection.setRequestProperty("Authorization", "Bearer $apiKey")
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")

        val sourceText = buildString {
            appendLine("자료 출처: ${item.source}")
            appendLine("제목: ${item.title}")
            appendLine("게시일: ${item.date}")
            appendLine("원문 URL: ${item.link}")
            appendLine("본문:")
            appendLine(item.body.take(18000))
        }
        val instruction = """
            당신은 한국어 지역·정치 전문 뉴스 기자의 기사 초안 작성 보조자다.
            제공된 자료에 없는 사실, 인물 발언, 수치, 날짜, 직책을 절대 만들어내지 마라.
            확인되지 않은 내용은 추정하지 말고 [확인 필요]로 표시하라.
            제목, 부제 2~3개(각 줄은 ▷로 시작), 본문 순서로 작성하라.
            본문은 [프레스큐=정희도 기자] 다음에 시작하라.
            문체는 간결한 기사체 평서문으로 작성하고, 직접 인용은 원문에 실제 존재하는 문장만 사용하라.
            자료가 보도자료 원문이 아니라 일부 추출문이라면 그 한계를 기사 초안 안에 표시하라.
            편집자 메모나 사실 확인 목록도 마지막에 별도 구분해 작성하라.
        """.trimIndent()
        val payload = org.json.JSONObject().apply {
            put("model", model)
            put("messages", org.json.JSONArray().apply {
                put(org.json.JSONObject().put("role", "developer").put("content", instruction))
                put(org.json.JSONObject().put("role", "user").put("content", sourceText))
            })
        }
        return try {
            connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val statusCode = connection.responseCode
            val stream = if (statusCode in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (statusCode !in 200..299) {
                throw java.io.IOException("OpenAI API 오류 ($statusCode): " + response.take(500))
            }
            val json = org.json.JSONObject(response)
            val text = json.getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
            val usage = json.optJSONObject("usage")
            val inputTokens = usage?.optInt("prompt_tokens", 0) ?: 0
            val outputTokens = usage?.optInt("completion_tokens", 0) ?: 0
            AiDraftResult(
                text = text,
                inputTokens = inputTokens,
                outputTokens = outputTokens,
                costUsd = estimateUsd(model, inputTokens, outputTokens)
            )
        } finally {
            connection.disconnect()
        }
    }
}

object GeminiArticleWriter {
    fun generate(item: PressItem, model: String, apiKey: String): AiDraftResult {
        val endpoint = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val connection = endpoint.openConnection() as HttpURLConnection
        connection.requestMethod = "POST"
        connection.connectTimeout = 20000
        connection.readTimeout = 90000
        connection.doOutput = true
        connection.setRequestProperty("x-goog-api-key", apiKey)
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")

        val sourceText = buildString {
            appendLine("자료 출처: ${item.source}")
            appendLine("제목: ${item.title}")
            appendLine("게시일: ${item.date}")
            appendLine("원문 URL: ${item.link}")
            appendLine("본문:")
            appendLine(item.body.take(18000))
        }
        val instruction = """
            당신은 한국어 지역·정치 전문 뉴스 기자의 기사 초안 작성 보조자다.
            제공된 자료에 없는 사실, 인물 발언, 수치, 날짜, 직책을 절대 만들어내지 마라.
            확인되지 않은 내용은 추정하지 말고 [확인 필요]로 표시하라.
            제목, 부제 2~3개(각 줄은 ▷로 시작), 본문 순서로 작성하라.
            본문은 [프레스큐=정희도 기자] 다음에 시작하라.
            문체는 간결한 기사체 평서문으로 작성하고, 직접 인용은 원문에 실제 존재하는 문장만 사용하라.
            자료가 보도자료 원문이 아니라 일부 추출문이라면 그 한계를 기사 초안 안에 표시하라.
            편집자 메모나 사실 확인 목록도 마지막에 별도 구분해 작성하라.
        """.trimIndent()
        val prompt = "$instruction\\n\\n$sourceText"
        val payload = org.json.JSONObject().apply {
            put("contents", org.json.JSONArray().put(
                org.json.JSONObject().put("role", "user").put("parts",
                    org.json.JSONArray().put(org.json.JSONObject().put("text", prompt)))
            ))
            put("generationConfig", org.json.JSONObject().put("temperature", 0.3))
        }
        return try {
            connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val statusCode = connection.responseCode
            val stream = if (statusCode in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (statusCode !in 200..299) {
                throw java.io.IOException("Gemini API 오류 ($statusCode): " + response.take(500))
            }
            val json = org.json.JSONObject(response)
            val candidates = json.optJSONArray("candidates")
                ?: throw java.io.IOException("Gemini 응답에 생성 후보가 없습니다: " + response.take(300))
            val parts = candidates.getJSONObject(0).getJSONObject("content").getJSONArray("parts")
            val text = buildString {
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    if (part.has("text")) append(part.getString("text"))
                }
            }.trim()
            if (text.isBlank()) throw java.io.IOException("Gemini가 텍스트를 반환하지 않았습니다.")
            val usage = json.optJSONObject("usageMetadata")
            AiDraftResult(
                text = text,
                inputTokens = usage?.optInt("promptTokenCount", 0) ?: 0,
                outputTokens = usage?.optInt("candidatesTokenCount", 0) ?: 0,
                costUsd = 0.0
            )
        } finally {
            connection.disconnect()
        }
    }
}


object MediaArchive {
    private const val MAX_ORIGINAL_BYTES = 50L * 1024 * 1024
    private const val MAX_SAVED_BYTES = 10 * 1024 * 1024

    fun downloadImages(context: Context, item: PressItem): PressItem {
        if (item.imageUrls.isBlank()) return item
        val folder = java.io.File(context.filesDir, "pressq_images").apply { mkdirs() }
        val saved = mutableListOf<String>()
        item.imageUrls.lines().filter { it.startsWith("http") }.take(2).forEachIndexed { index, address ->
            var originalFile: java.io.File? = null
            try {
                val connection = (URL(address).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 20000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "Mozilla/5.0 PressQ-Newsroom/0.2")
                }
                try {
                    val type = connection.contentType.orEmpty()
                    if (!type.startsWith("image/")) return@forEachIndexed
                    val announcedLength = connection.contentLengthLong
                    if (announcedLength > MAX_ORIGINAL_BYTES) return@forEachIndexed

                    val extension = when {
                        type.contains("png") -> "png"
                        type.contains("webp") -> "webp"
                        type.contains("gif") -> "gif"
                        else -> "jpg"
                    }
                    originalFile = java.io.File.createTempFile("pressq_original_", ".$extension", context.cacheDir)
                    connection.inputStream.use { input ->
                        originalFile!!.outputStream().use { output ->
                            val buffer = ByteArray(16 * 1024)
                            var total = 0L
                            while (true) {
                                val count = input.read(buffer)
                                if (count <= 0) break
                                total += count
                                if (total > MAX_ORIGINAL_BYTES) throw java.io.IOException("원본 이미지가 50MB를 초과합니다.")
                                output.write(buffer, 0, count)
                            }
                        }
                    }
                } finally {
                    connection.disconnect()
                }

                val source = originalFile ?: return@forEachIndexed
                val target = java.io.File(folder, item.link.hashCode().toUInt().toString(16) + "_" + index + ".jpg")
                if (source.length() <= MAX_SAVED_BYTES && extensionFor(source.name) != "gif") {
                    // Keep small originals unchanged only when they are JPEG; other formats
                    // are normalized to JPEG for a consistent archive format.
                    if (source.name.endsWith(".jpg", true) || source.name.endsWith(".jpeg", true)) {
                        source.copyTo(target, overwrite = true)
                    } else {
                        compressToLimit(source, target)
                    }
                } else {
                    compressToLimit(source, target)
                }
                if (target.exists() && target.length() <= MAX_SAVED_BYTES) saved.add(target.absolutePath)
                else target.delete()
            } catch (_: Exception) {
                // A failed image must not prevent the remaining press releases from being saved.
            } finally {
                originalFile?.delete()
            }
        }
        return item.copy(imageUrls = saved.joinToString("\n"))
    }

    private fun extensionFor(name: String): String = name.substringAfterLast('.', "").lowercase()

    private fun compressToLimit(source: java.io.File, target: java.io.File) {
        val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        android.graphics.BitmapFactory.decodeFile(source.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw java.io.IOException("이미지 해독 실패")

        var sample = 1
        while ((bounds.outWidth.toLong() / sample) * (bounds.outHeight.toLong() / sample) > 12_000_000L) {
            sample *= 2
        }
        var bitmap: android.graphics.Bitmap? = null
        while (sample <= 64 && bitmap == null) {
            val options = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
            bitmap = android.graphics.BitmapFactory.decodeFile(source.absolutePath, options)
            if (bitmap == null) sample *= 2
        }
        var image = bitmap ?: throw java.io.IOException("이미지 메모리 변환 실패")
        try {
            var quality = 92
            while (true) {
                val output = java.io.ByteArrayOutputStream()
                image.compress(android.graphics.Bitmap.CompressFormat.JPEG, quality, output)
                val bytes = output.toByteArray()
                if (bytes.size <= MAX_SAVED_BYTES) {
                    target.writeBytes(bytes)
                    return
                }
                if (quality > 58) {
                    quality -= 7
                } else {
                    val newWidth = (image.width * 0.85f).toInt().coerceAtLeast(1)
                    val newHeight = (image.height * 0.85f).toInt().coerceAtLeast(1)
                    if (newWidth >= image.width && newHeight >= image.height) {
                        throw java.io.IOException("10MB 이하로 압축할 수 없습니다.")
                    }
                    val scaled = android.graphics.Bitmap.createScaledBitmap(image, newWidth, newHeight, true)
                    if (scaled !== image) image.recycle()
                    image = scaled
                    quality = 88
                }
            }
        } finally {
            if (!image.isRecycled) image.recycle()
        }
    }
}

object DraftMaker {
    fun save(context: Context, item: PressItem): java.io.File {
        val folder = java.io.File(context.filesDir, "drafts").apply { mkdirs() }
        val safeTitle = item.title.replace(Regex("[^가-힣a-zA-Z0-9_-]"), "_").take(35)
        val file = java.io.File(folder, "${System.currentTimeMillis()}_$safeTitle.txt")
        val cleanBody = item.body
            .replace(Regex("\\s+"), " ")
            .trim()
        val draft = buildString {
            appendLine(item.title)
            appendLine()
            appendLine("[자료 출처] ${item.source}")
            appendLine("[원문] ${item.link}")
            appendLine()
            appendLine("[기사 초안]")
            appendLine(item.title)
            appendLine()
            appendLine("[프레스큐=정희도 기자]")
            appendLine()
            if (cleanBody.isNotBlank()) {
                appendLine(cleanBody)
            } else {
                appendLine("원문 본문을 자동으로 확보하지 못했습니다. 원문 확인 후 기사 내용을 작성해야 합니다.")
            }
            appendLine()
            appendLine("[편집 확인 사항]")
            appendLine("- 원문 발언 및 수치 확인")
            appendLine("- 날짜·직책·기관명 확인")
            appendLine("- 사진 출처 및 사용 조건 확인")
            if (item.imageUrls.isNotBlank()) {
                appendLine("- 앱 내부 이미지 저장 경로:")
                item.imageUrls.lines().forEach { appendLine(it) }
            }
        }
        file.writeText(draft, Charsets.UTF_8)
        return file
    }

    fun saveGenerated(context: Context, item: PressItem, generated: String): java.io.File {
        val folder = java.io.File(context.filesDir, "drafts").apply { mkdirs() }
        val safeTitle = item.title.replace(Regex("[^가-힣a-zA-Z0-9_-]"), "_").take(35)
        val file = java.io.File(folder, "${System.currentTimeMillis()}_AI_$safeTitle.md")
        val content = buildString {
            appendLine("# ${item.title}")
            appendLine()
            appendLine("- 출처: ${item.source}")
            appendLine("- 원문: ${item.link}")
            appendLine()
            appendLine(generated)
        }
        file.writeText(content, Charsets.UTF_8)
        return file
    }
}


/**
 * OpenAI key storage: AES-GCM ciphertext in private app preferences;
 * AES key is protected by Android Keystore.
 */
object OpenAiKeyStore {
    private const val PREF = "openai_secure_store"
    private const val KEY_ALIAS = "pressq_openai_key_v1"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"

    fun write(context: Context, apiKey: String) {
        val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val key = if (ks.containsAlias(KEY_ALIAS)) {
            (ks.getEntry(KEY_ALIAS, null) as java.security.KeyStore.SecretKeyEntry).secretKey
        } else {
            val generator = javax.crypto.KeyGenerator.getInstance(
                android.security.keystore.KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore"
            )
            generator.init(android.security.keystore.KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or
                    android.security.keystore.KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true).build())
            generator.generateKey()
        }
        val cipher = javax.crypto.Cipher.getInstance(TRANSFORMATION)
        cipher.init(javax.crypto.Cipher.ENCRYPT_MODE, key)
        val encrypted = cipher.doFinal(apiKey.toByteArray(Charsets.UTF_8))
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString("iv", android.util.Base64.encodeToString(cipher.iv, android.util.Base64.NO_WRAP))
            .putString("data", android.util.Base64.encodeToString(encrypted, android.util.Base64.NO_WRAP))
            .apply()
    }

    fun read(context: Context): String {
        return try {
            val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            val ivText = prefs.getString("iv", null) ?: return ""
            val dataText = prefs.getString("data", null) ?: return ""
            val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            val key = (ks.getEntry(KEY_ALIAS, null) as java.security.KeyStore.SecretKeyEntry).secretKey
            val cipher = javax.crypto.Cipher.getInstance(TRANSFORMATION)
            cipher.init(javax.crypto.Cipher.DECRYPT_MODE, key,
                javax.crypto.spec.GCMParameterSpec(128, android.util.Base64.decode(ivText, android.util.Base64.NO_WRAP)))
            cipher.doFinal(android.util.Base64.decode(dataText, android.util.Base64.NO_WRAP))
                .toString(Charsets.UTF_8)
        } catch (_: Exception) { "" }
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply()
        try {
            java.security.KeyStore.getInstance("AndroidKeyStore").apply {
                load(null)
                deleteEntry(KEY_ALIAS)
            }
        } catch (_: Exception) {}
    }
}


/**
 * Gemini API key encrypted with AES-GCM; AES key is protected by Android Keystore.
 */
object GeminiKeyStore {
    private const val PREF = "gemini_secure_store"
    private const val KEY_ALIAS = "pressq_gemini_key_v1"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"

    fun write(context: Context, apiKey: String) {
        val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val key = if (ks.containsAlias(KEY_ALIAS)) {
            (ks.getEntry(KEY_ALIAS, null) as java.security.KeyStore.SecretKeyEntry).secretKey
        } else {
            val generator = javax.crypto.KeyGenerator.getInstance(
                android.security.keystore.KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore"
            )
            generator.init(android.security.keystore.KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or
                    android.security.keystore.KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true).build())
            generator.generateKey()
        }
        val cipher = javax.crypto.Cipher.getInstance(TRANSFORMATION)
        cipher.init(javax.crypto.Cipher.ENCRYPT_MODE, key)
        val encrypted = cipher.doFinal(apiKey.toByteArray(Charsets.UTF_8))
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString("iv", android.util.Base64.encodeToString(cipher.iv, android.util.Base64.NO_WRAP))
            .putString("data", android.util.Base64.encodeToString(encrypted, android.util.Base64.NO_WRAP))
            .apply()
    }

    fun read(context: Context): String {
        return try {
            val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            val ivText = prefs.getString("iv", null) ?: return ""
            val dataText = prefs.getString("data", null) ?: return ""
            val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            val key = (ks.getEntry(KEY_ALIAS, null) as java.security.KeyStore.SecretKeyEntry).secretKey
            val cipher = javax.crypto.Cipher.getInstance(TRANSFORMATION)
            cipher.init(javax.crypto.Cipher.DECRYPT_MODE, key,
                javax.crypto.spec.GCMParameterSpec(128, android.util.Base64.decode(ivText, android.util.Base64.NO_WRAP)))
            cipher.doFinal(android.util.Base64.decode(dataText, android.util.Base64.NO_WRAP)).toString(Charsets.UTF_8)
        } catch (_: Exception) { "" }
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply()
        try {
            java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null); deleteEntry(KEY_ALIAS) }
        } catch (_: Exception) {}
    }
}


/**
 * Credentials are encrypted with an AES key protected by Android Keystore.
 * The encryption key never leaves the device.
 */
object CmsCredentialStore {
    private const val PREF = "cms_secure_store"
    private const val KEY_ALIAS = "pressq_cms_credentials_v1"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"

    fun write(context: Context, username: String, password: String) {
        val keyStore = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val key = if (keyStore.containsAlias(KEY_ALIAS)) {
            (keyStore.getEntry(KEY_ALIAS, null) as java.security.KeyStore.SecretKeyEntry).secretKey
        } else {
            val generator = javax.crypto.KeyGenerator.getInstance(
                android.security.keystore.KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore"
            )
            generator.init(
                android.security.keystore.KeyGenParameterSpec.Builder(
                    KEY_ALIAS,
                    android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or
                        android.security.keystore.KeyProperties.PURPOSE_DECRYPT
                ).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setRandomizedEncryptionRequired(true)
                    .build()
            )
            generator.generateKey()
        }
        val cipher = javax.crypto.Cipher.getInstance(TRANSFORMATION)
        cipher.init(javax.crypto.Cipher.ENCRYPT_MODE, key)
        val plain = "$username\u0000$password".toByteArray(Charsets.UTF_8)
        val encrypted = cipher.doFinal(plain)
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        prefs.edit()
            .putString("iv", android.util.Base64.encodeToString(cipher.iv, android.util.Base64.NO_WRAP))
            .putString("data", android.util.Base64.encodeToString(encrypted, android.util.Base64.NO_WRAP))
            .apply()
    }

    fun read(context: Context): Pair<String, String> {
        return try {
            val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            val iv = android.util.Base64.decode(prefs.getString("iv", "") ?: "", android.util.Base64.NO_WRAP)
            val data = android.util.Base64.decode(prefs.getString("data", "") ?: "", android.util.Base64.NO_WRAP)
            if (iv.isEmpty() || data.isEmpty()) return "" to ""
            val keyStore = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            val key = (keyStore.getEntry(KEY_ALIAS, null) as java.security.KeyStore.SecretKeyEntry).secretKey
            val cipher = javax.crypto.Cipher.getInstance(TRANSFORMATION)
            cipher.init(javax.crypto.Cipher.DECRYPT_MODE, key, javax.crypto.spec.GCMParameterSpec(128, iv))
            val decoded = cipher.doFinal(data).toString(Charsets.UTF_8)
            val split = decoded.split('\u0000', limit = 2)
            if (split.size == 2) split[0] to split[1] else "" to ""
        } catch (_: Exception) { "" to "" }
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply()
        try {
            java.security.KeyStore.getInstance("AndroidKeyStore").apply {
                load(null)
                deleteEntry(KEY_ALIAS)
            }
        } catch (_: Exception) {}
    }
}

class CmsLoginActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private lateinit var progress: android.widget.ProgressBar
    private lateinit var errorPanel: LinearLayout
    private lateinit var errorText: TextView
    private val cmsUrl = "https://admin.pressq.kr"

    @Suppress("SetJavaScriptEnabled", "DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val credentials = CmsCredentialStore.read(this)
        if (credentials.first.isBlank() || credentials.second.isBlank()) {
            Toast.makeText(this, "먼저 CMS 로그인 정보를 설정해 주세요.", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        val purple = 0xff5426a8.toInt()
        val ink = 0xff211b2b.toInt()
        val muted = 0xff777181.toInt()
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xfff7f5fb.toInt())
        }

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(24, 12, 16, 12)
            setBackgroundColor(android.graphics.Color.WHITE)
        }
        val title = TextView(this).apply {
            text = "PressQ  /  CMS"
            textSize = 18f
            setTextColor(ink)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        toolbar.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val reload = TextView(this).apply {
            text = "새로고침"
            textSize = 13f
            setTextColor(purple)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(12, 10, 12, 10)
            setOnClickListener { showLoading(); webView.reload() }
        }
        toolbar.addView(reload)
        page.addView(toolbar)

        progress = android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = false
            max = 100
            progressTintList = android.content.res.ColorStateList.valueOf(purple)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(0xffe9e3f0.toInt())
        }
        page.addView(progress, LinearLayout.LayoutParams(-1, 4))

        val frame = android.widget.FrameLayout(this)
        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = true
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            settings.setSupportZoom(true)
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView, newProgress: Int) {
                    this@CmsLoginActivity.progress.progress = newProgress
                    this@CmsLoginActivity.progress.visibility = if (newProgress >= 100) android.view.View.GONE else android.view.View.VISIBLE
                }
            }
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                    this@CmsLoginActivity.errorPanel.visibility = android.view.View.GONE
                    this@CmsLoginActivity.progress.visibility = android.view.View.VISIBLE
                    this@CmsLoginActivity.progress.progress = 5
                }

                override fun onPageFinished(view: WebView, url: String) {
                    this@CmsLoginActivity.progress.progress = 100
                    this@CmsLoginActivity.progress.visibility = android.view.View.GONE
                    if (android.net.Uri.parse(url).host == "admin.pressq.kr") {
                        val user = org.json.JSONObject.quote(credentials.first)
                        val pass = org.json.JSONObject.quote(credentials.second)
                        val script = """
                            (function() {
                              const u = document.querySelector('input[type="text"], input[name*="id" i], input[placeholder*="아이디"]');
                              const p = document.querySelector('input[type="password"], input[name*="pw" i], input[placeholder*="비밀번호"]');
                              function setVal(el, val) {
                                if (!el) return;
                                const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
                                setter.call(el, val);
                                el.dispatchEvent(new Event('input', {bubbles:true}));
                                el.dispatchEvent(new Event('change', {bubbles:true}));
                              }
                              setVal(u, $user);
                              setVal(p, $pass);
                              const candidates = Array.from(document.querySelectorAll('input[type="checkbox"], label'));
                              const auto = candidates.find(el => ((el.innerText || el.parentElement?.innerText || el.getAttribute('aria-label') || '').includes('자동 로그인')));
                              if (auto) {
                                if (auto.tagName === 'INPUT' && !auto.checked) auto.click();
                                else if (auto.tagName === 'LABEL') {
                                  const cb = auto.querySelector('input[type="checkbox"]') || auto.control;
                                  if (cb && !cb.checked) cb.click();
                                }
                              }
                            })();
                        """.trimIndent()
                        view.evaluateJavascript(script, null)
                    }
                }

                override fun onReceivedError(
                    view: WebView,
                    request: android.webkit.WebResourceRequest,
                    error: android.webkit.WebResourceError
                ) {
                    if (request.isForMainFrame) showError("CMS 페이지에 연결하지 못했습니다.\n${error.description}")
                }

                override fun onReceivedHttpError(
                    view: WebView,
                    request: android.webkit.WebResourceRequest,
                    response: android.webkit.WebResourceResponse
                ) {
                    if (request.isForMainFrame && response.statusCode >= 400) {
                        showError("CMS 서버 응답 오류 (${response.statusCode})")
                    }
                }

                override fun onReceivedSslError(
                    view: WebView,
                    handler: android.webkit.SslErrorHandler,
                    error: android.net.http.SslError
                ) {
                    handler.cancel()
                    showError("보안 인증서 오류로 CMS 연결을 중단했습니다.")
                }
            }
        }
        frame.addView(webView, android.widget.FrameLayout.LayoutParams(-1, -1))

        errorPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = android.view.Gravity.CENTER
            setPadding(32, 24, 32, 24)
            setBackgroundColor(0xfff7f5fb.toInt())
            visibility = android.view.View.GONE
        }
        errorText = TextView(this).apply {
            textSize = 15f
            setTextColor(ink)
            gravity = android.view.Gravity.CENTER
        }
        errorPanel.addView(errorText, LinearLayout.LayoutParams(-1, -2))
        val retry = TextView(this).apply {
            text = "다시 연결"
            textSize = 14f
            setTextColor(android.graphics.Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = android.view.Gravity.CENTER
            setPadding(24, 14, 24, 14)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(purple)
                cornerRadius = 18f
            }
            setOnClickListener { showLoading(); webView.loadUrl(cmsUrl) }
        }
        errorPanel.addView(retry, LinearLayout.LayoutParams(-2, -2).apply { topMargin = 20 })
        frame.addView(errorPanel, android.widget.FrameLayout.LayoutParams(-1, -1))
        page.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(page)
        showLoading()
        webView.loadUrl(cmsUrl)
    }

    private fun showLoading() {
        if (::progress.isInitialized) {
            progress.visibility = android.view.View.VISIBLE
            progress.progress = 5
        }
        if (::errorPanel.isInitialized) errorPanel.visibility = android.view.View.GONE
    }

    private fun showError(message: String) {
        runOnUiThread {
            if (::progress.isInitialized) progress.visibility = android.view.View.GONE
            if (::errorText.isInitialized) errorText.text = message
            if (::errorPanel.isInitialized) errorPanel.visibility = android.view.View.VISIBLE
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.loadUrl("about:blank")
            webView.removeAllViews()
            webView.destroy()
        }
        super.onDestroy()
    }
}

