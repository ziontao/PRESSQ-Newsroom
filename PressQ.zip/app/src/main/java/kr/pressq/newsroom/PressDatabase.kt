package kr.pressq.newsroom

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class PressDatabase(context: Context) : SQLiteOpenHelper(context, "pressq_news.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE press_items (
                link TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                published TEXT,
                source TEXT NOT NULL,
                body TEXT,
                image_urls TEXT,
                collected_at INTEGER NOT NULL
            )
        """.trimIndent())
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE press_items ADD COLUMN body TEXT")
            db.execSQL("ALTER TABLE press_items ADD COLUMN image_urls TEXT")
        }
    }
    fun save(items: List<PressItem>): List<PressItem> {
        val fresh = mutableListOf<PressItem>()
        writableDatabase.beginTransaction()
        try {
            items.forEach { item ->
                val values = ContentValues().apply {
                    put("link", item.link)
                    put("title", item.title)
                    put("published", item.date)
                    put("source", item.source)
                    put("body", item.body)
                    put("image_urls", item.imageUrls)
                    put("collected_at", System.currentTimeMillis())
                }
                val inserted = writableDatabase.insertWithOnConflict(
                    "press_items", null, values, SQLiteDatabase.CONFLICT_IGNORE
                )
                if (inserted != -1L) fresh.add(item)
            }
            writableDatabase.setTransactionSuccessful()
        } finally {
            writableDatabase.endTransaction()
        }
        return fresh
    }
    fun latest(limit: Int = 30): List<PressItem> {
        val result = mutableListOf<PressItem>()
        readableDatabase.rawQuery(
            "SELECT title, link, published, source, body, image_urls FROM press_items ORDER BY collected_at DESC LIMIT ?",
            arrayOf(limit.toString())
        ).use { c ->
            while (c.moveToNext()) result.add(
                PressItem(c.getString(0), c.getString(1), c.getString(2) ?: "", c.getString(3),
                    c.getString(4) ?: "", c.getString(5) ?: "")
            )
        }
        return result
    }
}
