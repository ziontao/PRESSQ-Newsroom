package kr.pressq.newsroom

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.net.HttpURLConnection
import java.net.URL
import org.jsoup.Jsoup
import java.util.concurrent.TimeUnit

data class PressItem(
    val title: String, val link: String, val date: String, val source: String,
    val body: String = "", val imageUrls: String = ""
)

class MainActivity : AppCompatActivity() {
    private lateinit var list: LinearLayout
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 20)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(0xfff5f5f5.toInt())
        }
        root.addView(TextView(this).apply {
            text = "PRESSQ · NEWSROOM\n서울 보도자료 모니터"
            textSize = 25f
            setTextColor(0xff171717.toInt())
            setPadding(0, 0, 0, 24)
        })
        status = TextView(this).apply {
            text = "휴대폰 직접 수집 · 30분 주기 예약"
            textSize = 14f
            setPadding(0, 0, 0, 18)
        }
        root.addView(status)

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(Button(this).apply {
            text = "지금 수집"
            setOnClickListener { refresh() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(Button(this).apply {
            text = "자동수집 켜기"
            setOnClickListener { schedule() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(buttons)
        val councilButton = Button(this).apply {
            text = "서울시의회 보도자료 게시판 열기"
            setOnClickListener {
                startActivity(android.content.Intent(
                    android.content.Intent.ACTION_VIEW,
                    android.net.Uri.parse("https://www.smc.seoul.kr/publish/view.do?menuId=001003006")
                ))
            }
        }
        root.addView(councilButton)
        root.addView(Button(this).apply {
            text = "PRESSQ CMS 로그인 / 임시저장"
            setOnClickListener { openCms() }
        })
        root.addView(Button(this).apply {
            text = "CMS 로그인 정보 설정"
            setOnClickListener { editCmsCredentials() }
        })

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this)
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        schedule()
        refresh()
    }

    private fun editCmsCredentials() {
        val saved = CmsCredentialStore.read(this)
        val idInput = EditText(this).apply {
            hint = "CMS 아이디"
            setText(saved.first)
            isSingleLine = true
        }
        val pwInput = EditText(this).apply {
            hint = "CMS 비밀번호"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(saved.second)
            isSingleLine = true
        }
        val remember = CheckBox(this).apply {
            text = "이 기기에 로그인 정보 암호화 저장"
            isChecked = saved.first.isNotBlank() && saved.second.isNotBlank()
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 8, 32, 0)
            addView(idInput)
            addView(pwInput)
            addView(remember)
            addView(TextView(this@MainActivity).apply {
                text = "정보는 이 휴대폰 안에서 암호화해 보관합니다. 앱 삭제 또는 데이터 초기화 시 저장 정보가 사라질 수 있습니다."
                textSize = 12f
            })
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("PRESSQ CMS 로그인 설정")
            .setView(panel)
            .setNegativeButton("취소", null)
            .setNeutralButton("저장정보 삭제") { _, _ -> CmsCredentialStore.clear(this) }
            .setPositiveButton("저장") { _, _ ->
                if (remember.isChecked && idInput.text.isNotBlank() && pwInput.text.isNotBlank()) {
                    CmsCredentialStore.write(this, idInput.text.toString(), pwInput.text.toString())
                    Toast.makeText(this, "CMS 로그인 정보를 암호화해 저장했습니다.", Toast.LENGTH_LONG).show()
                } else {
                    CmsCredentialStore.clear(this)
                    Toast.makeText(this, "저장 정보를 삭제했습니다.", Toast.LENGTH_LONG).show()
                }
            }.show()
    }

    private fun openCms() {
        val creds = CmsCredentialStore.read(this)
        if (creds.first.isBlank() || creds.second.isBlank()) {
            Toast.makeText(this, "먼저 CMS 로그인 정보를 설정해 주세요.", Toast.LENGTH_LONG).show()
            editCmsCredentials()
            return
        }
        startActivity(android.content.Intent(this, CmsLoginActivity::class.java))
    }

    private fun schedule() {
        val request = PeriodicWorkRequestBuilder<PressWorker>(30, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "pressq-monitor", ExistingPeriodicWorkPolicy.UPDATE, request
        )
        status.text = "자동수집 예약됨 · 최소 30분 주기 (절전 상태에 따라 지연 가능)"
    }

    private fun refresh() {
        status.text = "서울시 공식 RSS 확인 중…"
        Thread {
            try {
                val fetched = PressFetcher.fetchSeoul() + PressFetcher.fetchCouncilHomepage()
                val archived = fetched.map { MediaArchive.downloadImages(this, it) }
                val database = PressDatabase(this)
                database.save(archived)
                val items = database.latest()
                runOnUiThread {
                    list.removeAllViews()
                    if (items.isEmpty()) {
                        addMessage("RSS 응답은 받았지만 표시할 게시물이 없습니다.")
                    } else {
                        items.forEach { item ->
                            val cardBox = LinearLayout(this).apply {
                                orientation = LinearLayout.VERTICAL
                                setPadding(14, 14, 14, 14)
                            }
                            val card = TextView(this).apply {
                                text = "${item.source} · ${item.date}\\n${item.title}" +
                                    (if (item.body.isNotBlank()) "\\n\\n" + item.body.take(260) else "") +
                                    (if (item.imageUrls.isNotBlank()) "\\n\\n저장 이미지: " + item.imageUrls.lines().size + "개" else "") +
                                    "\\n\\n원문 열기 ↗"
                                textSize = 16f
                                setTextColor(0xff222222.toInt())
                                setPadding(4, 4, 4, 10)
                                setOnClickListener {
                                    startActivity(android.content.Intent(
                                        android.content.Intent.ACTION_VIEW,
                                        android.net.Uri.parse(item.link)
                                    ))
                                }
                            }
                            cardBox.addView(card)
                            cardBox.addView(Button(this).apply {
                                text = "기사 초안 만들기"
                                setOnClickListener {
                                    try {
                                        val file = DraftMaker.save(this@MainActivity, item)
                                        Toast.makeText(this@MainActivity,
                                            "초안 저장 완료: ${file.name}", Toast.LENGTH_LONG).show()
                                    } catch (e: Exception) {
                                        Toast.makeText(this@MainActivity,
                                            "초안 저장 실패: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
                                    }
                                }
                            })
                            cardBox.addView(Button(this).apply {
                                text = "AI 기사 초안 작성"
                                setOnClickListener { requestAiDraft(item) }
                            })
                            list.addView(cardBox)
                            val divider = android.view.View(this).apply {
                                setBackgroundColor(0xffdddddd.toInt())
                            }
                            list.addView(divider, LinearLayout.LayoutParams(-1, 1))
                        }
                    }
                    status.text = "휴대폰 저장 자료 ${items.size}건 · 서울시 및 시의회 확인 완료"
                }
            } catch (e: Exception) {
                runOnUiThread {
                    list.removeAllViews()
                    addMessage("수집 실패: ${e.localizedMessage ?: "네트워크 또는 피드 응답 오류"}")
                    status.text = "수집에 실패했습니다."
                }
            }
        }.start()
    }

    private fun requestAiDraft(item: PressItem) {
        val providerGroup = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val geminiRadio = RadioButton(this).apply { id = 1; text = "Gemini 무료"; isChecked = true }
        val openAiRadio = RadioButton(this).apply { id = 2; text = "OpenAI 유료" }
        providerGroup.addView(geminiRadio)
        providerGroup.addView(openAiRadio)

        val savedGeminiKey = GeminiKeyStore.read(this)
        val savedOpenAiKey = OpenAiKeyStore.read(this)
        val modelInput = EditText(this).apply {
            setText("gemini-3.8-flash")
            hint = "모델 ID"
            isSingleLine = true
        }
        val keyInput = EditText(this).apply {
            hint = "Gemini API Key"
            setText(savedGeminiKey)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val rememberKey = CheckBox(this).apply {
            text = "이 기기에 API 키 암호화 저장"
            isChecked = savedGeminiKey.isNotBlank()
        }
        val privacyNote = TextView(this).apply {
            text = "Gemini 무료 등급은 사용량 제한이 있으며 입력한 자료가 Google 제품 개선에 사용될 수 있습니다. 민감하거나 비공개인 취재자료는 입력하지 마세요. 기기 내 암호화는 파일 유출 위험을 줄이지만 루팅·디버깅·실행 중 메모리 노출까지 막지는 못합니다."
            textSize = 12f
        }
        providerGroup.setOnCheckedChangeListener { _, checkedId ->
            val isGemini = checkedId == 1
            val saved = if (isGemini) savedGeminiKey else savedOpenAiKey
            keyInput.setText(saved)
            keyInput.hint = if (isGemini) "Gemini API Key" else "OpenAI API Key"
            modelInput.setText(if (isGemini) "gemini-3.8-flash" else "gpt-6-luna")
            rememberKey.isChecked = saved.isNotBlank()
            privacyNote.text = if (isGemini) {
                "Gemini 무료 등급은 사용량 제한이 있으며 입력한 자료가 Google 제품 개선에 사용될 수 있습니다. 민감하거나 비공개인 취재자료는 입력하지 마세요. 기기 내 암호화는 파일 유출 위험을 줄이지만 루팅·디버깅·실행 중 메모리 노출까지 막지는 못합니다."
            } else {
                "OpenAI API는 ChatGPT 구독과 별도 과금입니다. 전용 프로젝트 키와 낮은 사용 한도를 권장합니다. 모바일 앱 직접 호출은 키 추출 위험이 있어 기기 내 암호화만으로 완전히 방지할 수 없습니다."
            }
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 8, 32, 0)
            addView(providerGroup)
            addView(TextView(this@MainActivity).apply { text = "모델 ID" })
            addView(modelInput)
            addView(TextView(this@MainActivity).apply { text = "API Key" })
            addView(keyInput)
            addView(rememberKey)
            addView(privacyNote)
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("AI 기사 초안 설정")
            .setView(panel)
            .setNegativeButton("취소", null)
            .setPositiveButton("작성") { _, _ ->
                val useGemini = providerGroup.checkedRadioButtonId == 1
                val model = modelInput.text.toString().trim()
                val key = keyInput.text.toString().trim()
                if (rememberKey.isChecked && key.isNotBlank()) {
                    if (useGemini) GeminiKeyStore.write(this, key) else OpenAiKeyStore.write(this, key)
                } else {
                    if (useGemini) GeminiKeyStore.clear(this) else OpenAiKeyStore.clear(this)
                }
                if (model.isBlank() || key.isBlank()) {
                    Toast.makeText(this, "모델 ID와 API Key를 입력해 주세요.", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                status.text = if (useGemini) "Gemini로 기사 초안 생성 중…" else "OpenAI로 기사 초안 생성 중…"
                Thread {
                    try {
                        val result = if (useGemini) {
                            GeminiArticleWriter.generate(item, model, key)
                        } else {
                            AiArticleWriter.generate(item, model, key)
                        }
                        val file = DraftMaker.saveGenerated(this, item, result.text)
                        runOnUiThread {
                            val costLabel = when {
                                useGemini -> " · Gemini 무료 등급 요청"
                                result.costUsd != null -> " · 예상 비용 $${"%.6f".format(java.util.Locale.US, result.costUsd)}"
                                else -> " · 비용 산정 불가"
                            }
                            status.text = "AI 초안 저장 완료: ${file.name}$costLabel"
                            Toast.makeText(this,
                                "AI 초안 저장 완료\\n입력 ${result.inputTokens} tokens / 출력 ${result.outputTokens} tokens$costLabel",
                                Toast.LENGTH_LONG).show()
                        }
                    } catch (e: Exception) {
                        runOnUiThread {
                            status.text = "AI 초안 생성 실패"
                            val msg = e.localizedMessage ?: "API 요청 오류"
                            Toast.makeText(this,
                                if (useGemini) "Gemini 요청 실패(무료 한도·키·모델 확인): $msg" else msg,
                                Toast.LENGTH_LONG).show()
                        }
                    }
                }.start()
            }
            .show()
    }

    private fun addMessage(message: String) {
        list.addView(TextView(this).apply {
            text = message
            textSize = 15f
            setPadding(12, 24, 12, 24)
        })
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(
                NotificationChannel("pressq_new", "새 보도자료", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
    }
}

object PressFetcher {
    private const val SEOUL_RSS =
        "https://seoulboard.seoul.go.kr/rss/RSSGenerator?bbsNo=158"

    fun fetchSeoul(): List<PressItem> =
        fetchRss("서울시", SEOUL_RSS).take(15).map { item -> fetchDetail(item) }

    private fun fetchDetail(item: PressItem): PressItem {
        val connection = (URL(item.link).openConnection() as HttpURLConnection).apply {
            connectTimeout = 10000
            readTimeout = 10000
            setRequestProperty("User-Agent", "Mozilla/5.0 PRESSQ-Newsroom/0.1")
        }
        return try {
            val html = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val doc = Jsoup.parse(html, item.link)
            doc.select("script,style,nav,header,footer,aside").remove()
            val candidates = listOf(
                "#content", ".view_cont", ".board_view", ".bbs_view",
                ".view-content", "article", "main"
            )
            val body = candidates.asSequence()
                .mapNotNull { selector -> doc.selectFirst(selector)?.text()?.trim() }
                .firstOrNull { it.length > 80 }
                ?: doc.body()?.text()?.take(5000).orEmpty()
            val images = doc.select("img[src]")
                .map { it.absUrl("src") }
                .filter { it.startsWith("http") }
                .distinct()
                .take(12)
                .joinToString("\\n")
            item.copy(body = body.take(12000), imageUrls = images)
        } catch (_: Exception) {
            item
        } finally {
            connection.disconnect()
        }
    }

    // The council homepage publicly renders its latest press-release headlines.
    // Collect only anchors whose visible text resembles a press-release headline.
    // Detailed board pagination and attachments still require a dedicated parser.
    fun fetchCouncilHomepage(): List<PressItem> {
        val connection = (URL("https://www.smc.seoul.kr/main/index.do").openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 15000
            setRequestProperty("User-Agent", "Mozilla/5.0 PRESSQ-Newsroom/0.1")
        }
        return try {
            val html = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val document = Jsoup.parse(html, "https://www.smc.seoul.kr")
            val results = mutableListOf<PressItem>()
            val seen = mutableSetOf<String>()
            document.select("a[href]").forEach { anchor ->
                val title = anchor.text().replace(Regex("\\s+"), " ").trim()
                val href = anchor.absUrl("href")
                val looksLikeRelease = title.length >= 12 &&
                    (title.contains("서울시의회") || title.contains("의원") ||
                     title.contains("위원장") || title.contains("부의장")) &&
                    !title.contains("더보기")
                if (looksLikeRelease && href.startsWith("https://www.smc.seoul.kr") && seen.add(href)) {
                    results.add(PressItem(title, href, "", "서울시의회"))
                }
            }
            results.take(20)
        } finally {
            connection.disconnect()
        }
    }

    fun fetchRss(source: String, address: String): List<PressItem> {
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 15000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "Mozilla/5.0 PRESSQ-Newsroom/0.1")
            setRequestProperty("Accept", "application/rss+xml, application/xml, text/xml, */*")
        }
        return try {
            connection.inputStream.use { input ->
                val parser = XmlPullParserFactory.newInstance().newPullParser()
                parser.setInput(input, "UTF-8")
                val results = mutableListOf<PressItem>()
                var event = parser.eventType
                var inItem = false
                var title = ""
                var link = ""
                var date = ""
                var currentTag = ""

                while (event != XmlPullParser.END_DOCUMENT) {
                    when (event) {
                        XmlPullParser.START_TAG -> {
                            currentTag = parser.name.lowercase()
                            if (currentTag == "item" || currentTag == "entry") {
                                inItem = true
                                title = ""
                                link = ""
                                date = ""
                            } else if (inItem && currentTag == "link") {
                                val href = parser.getAttributeValue(null, "href")
                                if (!href.isNullOrBlank()) link = href
                            }
                        }
                        XmlPullParser.TEXT -> if (inItem) {
                            when (currentTag) {
                                "title" -> title += parser.text
                                "link" -> link += parser.text
                                "pubdate", "published", "updated", "dc:date" -> date += parser.text
                            }
                        }
                        XmlPullParser.END_TAG -> {
                            val tag = parser.name.lowercase()
                            if (inItem && (tag == "item" || tag == "entry")) {
                                if (title.isNotBlank() && link.isNotBlank()) {
                                    results.add(PressItem(title.trim(), link.trim(), date.trim(), source))
                                }
                                inItem = false
                            }
                            currentTag = ""
                        }
                    }
                    event = parser.next()
                }
                results
            }
        } finally {
            connection.disconnect()
        }
    }
}

class PressWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        return try {
            val fetched = PressFetcher.fetchSeoul() + PressFetcher.fetchCouncilHomepage()
            val items = fetched.map { MediaArchive.downloadImages(applicationContext, it) }
            val database = PressDatabase(applicationContext)
            val newItems = database.save(items)

            if (newItems.isNotEmpty()) {
                val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                newItems.take(5).forEachIndexed { index, item ->
                    val notification = NotificationCompat.Builder(applicationContext, "pressq_new")
                        .setSmallIcon(android.R.drawable.ic_dialog_info)
                        .setContentTitle("새 서울시 보도자료")
                        .setContentText(item.title)
                        .setStyle(NotificationCompat.BigTextStyle().bigText(item.title))
                        .setAutoCancel(true)
                        .build()
                    manager.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt() + index, notification)
                }
            }
            Result.success()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}


data class AiDraftResult(
    val text: String,
    val inputTokens: Int,
    val outputTokens: Int,
    val costUsd: Double?
)

object AiArticleWriter {
    // Standard text-token rates per 1M tokens. Keep this aligned with OpenAI's live pricing.
    private val standardRatesUsd = mapOf(
        "gpt-6-luna" to Pair(0.10, 0.50),
        "gpt-6.1-terra" to Pair(1.00, 5.00),
        "gpt-6.1-sol" to Pair(2.00, 10.00),
        "gpt-6-astra" to Pair(10.00, 50.00)
    )

    fun estimateUsd(model: String, inputTokens: Int, outputTokens: Int): Double? {
        val rates = standardRatesUsd[model] ?: return null
        return (inputTokens * rates.first + outputTokens * rates.second) / 1_000_000.0
    }

    fun generate(item: PressItem, model: String, apiKey: String): AiDraftResult {
        val endpoint = URL("https://api.openai.com/v1/chat/completions")
        val connection = endpoint.openConnection() as HttpURLConnection
        connection.requestMethod = "POST"
        connection.connectTimeout = 20000
        connection.readTimeout = 90000
        connection.doOutput = true
        connection.setRequestProperty("Authorization", "Bearer $apiKey")
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")

        val sourceText = buildString {
            appendLine("자료 출처: ${item.source}")
            appendLine("제목: ${item.title}")
            appendLine("게시일: ${item.date}")
            appendLine("원문 URL: ${item.link}")
            appendLine("본문:")
            appendLine(item.body.take(18000))
        }
        val instruction = """
            당신은 한국어 지역·정치 전문 뉴스 기자의 기사 초안 작성 보조자다.
            제공된 자료에 없는 사실, 인물 발언, 수치, 날짜, 직책을 절대 만들어내지 마라.
            확인되지 않은 내용은 추정하지 말고 [확인 필요]로 표시하라.
            제목, 부제 2~3개(각 줄은 ▷로 시작), 본문 순서로 작성하라.
            본문은 [프레스큐=정희도 기자] 다음에 시작하라.
            문체는 간결한 기사체 평서문으로 작성하고, 직접 인용은 원문에 실제 존재하는 문장만 사용하라.
            자료가 보도자료 원문이 아니라 일부 추출문이라면 그 한계를 기사 초안 안에 표시하라.
            편집자 메모나 사실 확인 목록도 마지막에 별도 구분해 작성하라.
        """.trimIndent()
        val payload = org.json.JSONObject().apply {
            put("model", model)
            put("messages", org.json.JSONArray().apply {
                put(org.json.JSONObject().put("role", "developer").put("content", instruction))
                put(org.json.JSONObject().put("role", "user").put("content", sourceText))
            })
        }
        return try {
            connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val statusCode = connection.responseCode
            val stream = if (statusCode in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (statusCode !in 200..299) {
                throw java.io.IOException("OpenAI API 오류 ($statusCode): " + response.take(500))
            }
            val json = org.json.JSONObject(response)
            val text = json.getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
            val usage = json.optJSONObject("usage")
            val inputTokens = usage?.optInt("prompt_tokens", 0) ?: 0
            val outputTokens = usage?.optInt("completion_tokens", 0) ?: 0
            AiDraftResult(
                text = text,
                inputTokens = inputTokens,
                outputTokens = outputTokens,
                costUsd = estimateUsd(model, inputTokens, outputTokens)
            )
        } finally {
            connection.disconnect()
        }
    }
}

object GeminiArticleWriter {
    fun generate(item: PressItem, model: String, apiKey: String): AiDraftResult {
        val endpoint = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
        val connection = endpoint.openConnection() as HttpURLConnection
        connection.requestMethod = "POST"
        connection.connectTimeout = 20000
        connection.readTimeout = 90000
        connection.doOutput = true
        connection.setRequestProperty("x-goog-api-key", apiKey)
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")

        val sourceText = buildString {
            appendLine("자료 출처: ${item.source}")
            appendLine("제목: ${item.title}")
            appendLine("게시일: ${item.date}")
            appendLine("원문 URL: ${item.link}")
            appendLine("본문:")
            appendLine(item.body.take(18000))
        }
        val instruction = """
            당신은 한국어 지역·정치 전문 뉴스 기자의 기사 초안 작성 보조자다.
            제공된 자료에 없는 사실, 인물 발언, 수치, 날짜, 직책을 절대 만들어내지 마라.
            확인되지 않은 내용은 추정하지 말고 [확인 필요]로 표시하라.
            제목, 부제 2~3개(각 줄은 ▷로 시작), 본문 순서로 작성하라.
            본문은 [프레스큐=정희도 기자] 다음에 시작하라.
            문체는 간결한 기사체 평서문으로 작성하고, 직접 인용은 원문에 실제 존재하는 문장만 사용하라.
            자료가 보도자료 원문이 아니라 일부 추출문이라면 그 한계를 기사 초안 안에 표시하라.
            편집자 메모나 사실 확인 목록도 마지막에 별도 구분해 작성하라.
        """.trimIndent()
        val prompt = "$instruction\\n\\n$sourceText"
        val payload = org.json.JSONObject().apply {
            put("contents", org.json.JSONArray().put(
                org.json.JSONObject().put("role", "user").put("parts",
                    org.json.JSONArray().put(org.json.JSONObject().put("text", prompt)))
            ))
            put("generationConfig", org.json.JSONObject().put("temperature", 0.3))
        }
        return try {
            connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val statusCode = connection.responseCode
            val stream = if (statusCode in 200..299) connection.inputStream else connection.errorStream
            val response = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (statusCode !in 200..299) {
                throw java.io.IOException("Gemini API 오류 ($statusCode): " + response.take(500))
            }
            val json = org.json.JSONObject(response)
            val candidates = json.optJSONArray("candidates")
                ?: throw java.io.IOException("Gemini 응답에 생성 후보가 없습니다: " + response.take(300))
            val parts = candidates.getJSONObject(0).getJSONObject("content").getJSONArray("parts")
            val text = buildString {
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    if (part.has("text")) append(part.getString("text"))
                }
            }.trim()
            if (text.isBlank()) throw java.io.IOException("Gemini가 텍스트를 반환하지 않았습니다.")
            val usage = json.optJSONObject("usageMetadata")
            AiDraftResult(
                text = text,
                inputTokens = usage?.optInt("promptTokenCount", 0) ?: 0,
                outputTokens = usage?.optInt("candidatesTokenCount", 0) ?: 0,
                costUsd = 0.0
            )
        } finally {
            connection.disconnect()
        }
    }
}


object MediaArchive {
    private const val MAX_ORIGINAL_BYTES = 50L * 1024 * 1024
    private const val MAX_SAVED_BYTES = 10 * 1024 * 1024

    fun downloadImages(context: Context, item: PressItem): PressItem {
        if (item.imageUrls.isBlank()) return item
        val folder = java.io.File(context.filesDir, "pressq_images").apply { mkdirs() }
        val saved = mutableListOf<String>()
        item.imageUrls.lines().filter { it.startsWith("http") }.take(4).forEachIndexed { index, address ->
            var originalFile: java.io.File? = null
            try {
                val connection = (URL(address).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 20000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "Mozilla/5.0 PRESSQ-Newsroom/0.1")
                }
                try {
                    val type = connection.contentType.orEmpty()
                    if (!type.startsWith("image/")) return@forEachIndexed
                    val announcedLength = connection.contentLengthLong
                    if (announcedLength > MAX_ORIGINAL_BYTES) return@forEachIndexed

                    val extension = when {
                        type.contains("png") -> "png"
                        type.contains("webp") -> "webp"
                        type.contains("gif") -> "gif"
                        else -> "jpg"
                    }
                    originalFile = java.io.File.createTempFile("pressq_original_", ".$extension", context.cacheDir)
                    connection.inputStream.use { input ->
                        originalFile!!.outputStream().use { output ->
                            val buffer = ByteArray(16 * 1024)
                            var total = 0L
                            while (true) {
                                val count = input.read(buffer)
                                if (count <= 0) break
                                total += count
                                if (total > MAX_ORIGINAL_BYTES) throw java.io.IOException("원본 이미지가 50MB를 초과합니다.")
                                output.write(buffer, 0, count)
                            }
                        }
                    }
                } finally {
                    connection.disconnect()
                }

                val source = originalFile ?: return@forEachIndexed
                val target = java.io.File(folder, item.link.hashCode().toUInt().toString(16) + "_" + index + ".jpg")
                if (source.length() <= MAX_SAVED_BYTES && extensionFor(source.name) != "gif") {
                    // Keep small originals unchanged only when they are JPEG; other formats
                    // are normalized to JPEG for a consistent archive format.
                    if (source.name.endsWith(".jpg", true) || source.name.endsWith(".jpeg", true)) {
                        source.copyTo(target, overwrite = true)
                    } else {
                        compressToLimit(source, target)
                    }
                } else {
                    compressToLimit(source, target)
                }
                if (target.exists() && target.length() <= MAX_SAVED_BYTES) saved.add(target.absolutePath)
                else target.delete()
            } catch (_: Exception) {
                // A failed image must not prevent the remaining press releases from being saved.
            } finally {
                originalFile?.delete()
            }
        }
        return item.copy(imageUrls = saved.joinToString("\\n"))
    }

    private fun extensionFor(name: String): String = name.substringAfterLast('.', "").lowercase()

    private fun compressToLimit(source: java.io.File, target: java.io.File) {
        val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        android.graphics.BitmapFactory.decodeFile(source.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw java.io.IOException("이미지 해독 실패")

        var sample = 1
        while ((bounds.outWidth.toLong() / sample) * (bounds.outHeight.toLong() / sample) > 12_000_000L) {
            sample *= 2
        }
        var bitmap: android.graphics.Bitmap? = null
        while (sample <= 64 && bitmap == null) {
            val options = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
            bitmap = android.graphics.BitmapFactory.decodeFile(source.absolutePath, options)
            if (bitmap == null) sample *= 2
        }
        var image = bitmap ?: throw java.io.IOException("이미지 메모리 변환 실패")
        try {
            var quality = 92
            while (true) {
                val output = java.io.ByteArrayOutputStream()
                image.compress(android.graphics.Bitmap.CompressFormat.JPEG, quality, output)
                val bytes = output.toByteArray()
                if (bytes.size <= MAX_SAVED_BYTES) {
                    target.writeBytes(bytes)
                    return
                }
                if (quality > 58) {
                    quality -= 7
                } else {
                    val newWidth = (image.width * 0.85f).toInt().coerceAtLeast(1)
                    val newHeight = (image.height * 0.85f).toInt().coerceAtLeast(1)
                    if (newWidth >= image.width && newHeight >= image.height) {
                        throw java.io.IOException("10MB 이하로 압축할 수 없습니다.")
                    }
                    val scaled = android.graphics.Bitmap.createScaledBitmap(image, newWidth, newHeight, true)
                    if (scaled !== image) image.recycle()
                    image = scaled
                    quality = 88
                }
            }
        } finally {
            if (!image.isRecycled) image.recycle()
        }
    }
}

object DraftMaker {
    fun save(context: Context, item: PressItem): java.io.File {
        val folder = java.io.File(context.filesDir, "drafts").apply { mkdirs() }
        val safeTitle = item.title.replace(Regex("[^가-힣a-zA-Z0-9_-]"), "_").take(35)
        val file = java.io.File(folder, "${System.currentTimeMillis()}_$safeTitle.txt")
        val cleanBody = item.body
            .replace(Regex("\\s+"), " ")
            .trim()
        val draft = buildString {
            appendLine(item.title)
            appendLine()
            appendLine("[자료 출처] ${item.source}")
            appendLine("[원문] ${item.link}")
            appendLine()
            appendLine("[기사 초안]")
            appendLine(item.title)
            appendLine()
            appendLine("[프레스큐=정희도 기자]")
            appendLine()
            if (cleanBody.isNotBlank()) {
                appendLine(cleanBody)
            } else {
                appendLine("원문 본문을 자동으로 확보하지 못했습니다. 원문 확인 후 기사 내용을 작성해야 합니다.")
            }
            appendLine()
            appendLine("[편집 확인 사항]")
            appendLine("- 원문 발언 및 수치 확인")
            appendLine("- 날짜·직책·기관명 확인")
            appendLine("- 사진 출처 및 사용 조건 확인")
            if (item.imageUrls.isNotBlank()) {
                appendLine("- 앱 내부 이미지 저장 경로:")
                item.imageUrls.lines().forEach { appendLine(it) }
            }
        }
        file.writeText(draft, Charsets.UTF_8)
        return file
    }

    fun saveGenerated(context: Context, item: PressItem, generated: String): java.io.File {
        val folder = java.io.File(context.filesDir, "drafts").apply { mkdirs() }
        val safeTitle = item.title.replace(Regex("[^가-힣a-zA-Z0-9_-]"), "_").take(35)
        val file = java.io.File(folder, "${System.currentTimeMillis()}_AI_$safeTitle.md")
        val content = buildString {
            appendLine("# ${item.title}")
            appendLine()
            appendLine("- 출처: ${item.source}")
            appendLine("- 원문: ${item.link}")
            appendLine()
            appendLine(generated)
        }
        file.writeText(content, Charsets.UTF_8)
        return file
    }
}


/**
 * OpenAI key storage: AES-GCM ciphertext in private app preferences;
 * AES key is protected by Android Keystore.
 */
object OpenAiKeyStore {
    private const val PREF = "openai_secure_store"
    private const val KEY_ALIAS = "pressq_openai_key_v1"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"

    fun write(context: Context, apiKey: String) {
        val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val key = if (ks.containsAlias(KEY_ALIAS)) {
            (ks.getEntry(KEY_ALIAS, null) as java.security.KeyStore.SecretKeyEntry).secretKey
        } else {
            val generator = javax.crypto.KeyGenerator.getInstance(
                android.security.keystore.KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore"
            )
            generator.init(android.security.keystore.KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or
                    android.security.keystore.KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true).build())
            generator.generateKey()
        }
        val cipher = javax.crypto.Cipher.getInstance(TRANSFORMATION)
        cipher.init(javax.crypto.Cipher.ENCRYPT_MODE, key)
        val encrypted = cipher.doFinal(apiKey.toByteArray(Charsets.UTF_8))
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString("iv", android.util.Base64.encodeToString(cipher.iv, android.util.Base64.NO_WRAP))
            .putString("data", android.util.Base64.encodeToString(encrypted, android.util.Base64.NO_WRAP))
            .apply()
    }

    fun read(context: Context): String {
        return try {
            val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            val ivText = prefs.getString("iv", null) ?: return ""
            val dataText = prefs.getString("data", null) ?: return ""
            val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            val key = (ks.getEntry(KEY_ALIAS, null) as java.security.KeyStore.SecretKeyEntry).secretKey
            val cipher = javax.crypto.Cipher.getInstance(TRANSFORMATION)
            cipher.init(javax.crypto.Cipher.DECRYPT_MODE, key,
                javax.crypto.spec.GCMParameterSpec(128, android.util.Base64.decode(ivText, android.util.Base64.NO_WRAP)))
            cipher.doFinal(android.util.Base64.decode(dataText, android.util.Base64.NO_WRAP))
                .toString(Charsets.UTF_8)
        } catch (_: Exception) { "" }
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply()
        try {
            java.security.KeyStore.getInstance("AndroidKeyStore").apply {
                load(null)
                deleteEntry(KEY_ALIAS)
            }
        } catch (_: Exception) {}
    }
}


/**
 * Gemini API key encrypted with AES-GCM; AES key is protected by Android Keystore.
 */
object GeminiKeyStore {
    private const val PREF = "gemini_secure_store"
    private const val KEY_ALIAS = "pressq_gemini_key_v1"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"

    fun write(context: Context, apiKey: String) {
        val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val key = if (ks.containsAlias(KEY_ALIAS)) {
            (ks.getEntry(KEY_ALIAS, null) as java.security.KeyStore.SecretKeyEntry).secretKey
        } else {
            val generator = javax.crypto.KeyGenerator.getInstance(
                android.security.keystore.KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore"
            )
            generator.init(android.security.keystore.KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or
                    android.security.keystore.KeyProperties.PURPOSE_DECRYPT
            ).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true).build())
            generator.generateKey()
        }
        val cipher = javax.crypto.Cipher.getInstance(TRANSFORMATION)
        cipher.init(javax.crypto.Cipher.ENCRYPT_MODE, key)
        val encrypted = cipher.doFinal(apiKey.toByteArray(Charsets.UTF_8))
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit()
            .putString("iv", android.util.Base64.encodeToString(cipher.iv, android.util.Base64.NO_WRAP))
            .putString("data", android.util.Base64.encodeToString(encrypted, android.util.Base64.NO_WRAP))
            .apply()
    }

    fun read(context: Context): String {
        return try {
            val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            val ivText = prefs.getString("iv", null) ?: return ""
            val dataText = prefs.getString("data", null) ?: return ""
            val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            val key = (ks.getEntry(KEY_ALIAS, null) as java.security.KeyStore.SecretKeyEntry).secretKey
            val cipher = javax.crypto.Cipher.getInstance(TRANSFORMATION)
            cipher.init(javax.crypto.Cipher.DECRYPT_MODE, key,
                javax.crypto.spec.GCMParameterSpec(128, android.util.Base64.decode(ivText, android.util.Base64.NO_WRAP)))
            cipher.doFinal(android.util.Base64.decode(dataText, android.util.Base64.NO_WRAP)).toString(Charsets.UTF_8)
        } catch (_: Exception) { "" }
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply()
        try {
            java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null); deleteEntry(KEY_ALIAS) }
        } catch (_: Exception) {}
    }
}


/**
 * Credentials are encrypted with an AES key protected by Android Keystore.
 * The encryption key never leaves the device.
 */
object CmsCredentialStore {
    private const val PREF = "cms_secure_store"
    private const val KEY_ALIAS = "pressq_cms_credentials_v1"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"

    fun write(context: Context, username: String, password: String) {
        val keyStore = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val key = if (keyStore.containsAlias(KEY_ALIAS)) {
            (keyStore.getEntry(KEY_ALIAS, null) as java.security.KeyStore.SecretKeyEntry).secretKey
        } else {
            val generator = javax.crypto.KeyGenerator.getInstance(
                android.security.keystore.KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore"
            )
            generator.init(
                android.security.keystore.KeyGenParameterSpec.Builder(
                    KEY_ALIAS,
                    android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or
                        android.security.keystore.KeyProperties.PURPOSE_DECRYPT
                ).setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setRandomizedEncryptionRequired(true)
                    .build()
            )
            generator.generateKey()
        }
        val cipher = javax.crypto.Cipher.getInstance(TRANSFORMATION)
        cipher.init(javax.crypto.Cipher.ENCRYPT_MODE, key)
        val plain = "$username\u0000$password".toByteArray(Charsets.UTF_8)
        val encrypted = cipher.doFinal(plain)
        val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        prefs.edit()
            .putString("iv", android.util.Base64.encodeToString(cipher.iv, android.util.Base64.NO_WRAP))
            .putString("data", android.util.Base64.encodeToString(encrypted, android.util.Base64.NO_WRAP))
            .apply()
    }

    fun read(context: Context): Pair<String, String> {
        return try {
            val prefs = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            val iv = android.util.Base64.decode(prefs.getString("iv", "") ?: "", android.util.Base64.NO_WRAP)
            val data = android.util.Base64.decode(prefs.getString("data", "") ?: "", android.util.Base64.NO_WRAP)
            if (iv.isEmpty() || data.isEmpty()) return "" to ""
            val keyStore = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            val key = (keyStore.getEntry(KEY_ALIAS, null) as java.security.KeyStore.SecretKeyEntry).secretKey
            val cipher = javax.crypto.Cipher.getInstance(TRANSFORMATION)
            cipher.init(javax.crypto.Cipher.DECRYPT_MODE, key, javax.crypto.spec.GCMParameterSpec(128, iv))
            val decoded = cipher.doFinal(data).toString(Charsets.UTF_8)
            val split = decoded.split('\u0000', limit = 2)
            if (split.size == 2) split[0] to split[1] else "" to ""
        } catch (_: Exception) { "" to "" }
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply()
        try {
            java.security.KeyStore.getInstance("AndroidKeyStore").apply {
                load(null)
                deleteEntry(KEY_ALIAS)
            }
        } catch (_: Exception) {}
    }
}

class CmsLoginActivity : AppCompatActivity() {
    private lateinit var webView: WebView

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val credentials = CmsCredentialStore.read(this)
        if (credentials.first.isBlank() || credentials.second.isBlank()) {
            finish()
            return
        }
        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.loadsImagesAutomatically = true
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                if (android.net.Uri.parse(url).host == "admin.pressq.kr") {
                    val user = org.json.JSONObject.quote(credentials.first)
                    val pass = org.json.JSONObject.quote(credentials.second)
                    val script = """
                        (function() {
                          const u = document.querySelector('input[type="text"], input[name*="id" i], input[placeholder*="아이디"]');
                          const p = document.querySelector('input[type="password"], input[name*="pw" i], input[placeholder*="비밀번호"]');
                          function setVal(el, val) {
                            if (!el) return;
                            const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
                            setter.call(el, val);
                            el.dispatchEvent(new Event('input', {bubbles:true}));
                            el.dispatchEvent(new Event('change', {bubbles:true}));
                          }
                          setVal(u, $user);
                          setVal(p, $pass);
                          const candidates = Array.from(document.querySelectorAll('input[type="checkbox"], label'));
                          const auto = candidates.find(el => ((el.innerText || el.parentElement?.innerText || el.getAttribute('aria-label') || '').includes('자동 로그인')));
                          if (auto) {
                            if (auto.tagName === 'INPUT' && !auto.checked) auto.click();
                            else if (auto.tagName === 'LABEL') {
                              const cb = auto.querySelector('input[type="checkbox"]') || auto.control;
                              if (cb && !cb.checked) cb.click();
                            }
                          }
                        })();
                    """.trimIndent()
                    view.evaluateJavascript(script, null)
                }
            }
        }
        setContentView(webView)
        webView.loadUrl("https://admin.pressq.kr")
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) webView.destroy()
        super.onDestroy()
    }
}
