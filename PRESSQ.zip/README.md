# PRESSQ NEWSROOM Android — 개발 단계 0.7

## 이번 단계 추가
- 기사 카드에 'AI 기사 초안 작성' 버튼 추가
- OpenAI Chat Completions API 직접 호출
- 모델 ID와 API Key를 요청 시 입력
- API Key는 앱에 저장하지 않고 해당 요청 메모리에서만 사용
- 생성 결과를 앱 내부 drafts 폴더에 Markdown 파일로 저장
- 프레스큐 기사 작성 규칙(제목/부제/바이라인/기사체/확인 메모)을 프롬프트에 반영

## API 사용 및 보안 주의
- OpenAI API 사용에는 별도 API 키와 API 과금 계정이 필요합니다. ChatGPT 구독과 API 과금은 별개입니다.
- API 키를 모바일 앱에서 직접 전송하는 방식은 키 노출 위험이 있습니다. 현재 구현은 키를 저장하지 않지만, 앱에서 API를 직접 호출하는 구조 자체가 완전히 안전하지 않습니다. 개인 기기에서 시험하는 용도로만 사용하고, 운영 배포 시에는 서버 측 키 관리가 권장됩니다.
- 중간 서버를 두지 않는다는 사용자 요구를 유지하기 위해 현재는 기기에서 직접 호출하도록 구현했습니다.
- 모델 ID는 계정에서 API 사용 가능한 모델로 입력해야 합니다. 기본 입력값은 예시이며 접근 권한을 보장하지 않습니다.
- 생성 결과는 반드시 기자가 원문과 대조해 사실관계·인용·직책·날짜를 확인한 뒤 사용해야 합니다.

## 아직 미완성
- 서울시의회 게시판 전체 목록/상세/첨부파일 전용 파서
- 이미지 검수 및 출처/캡션 편집 UI
- CMS 자동 임시저장 (CMS API/로그인·세션/편집기 구조 확인 필요)
- AI 모델/프롬프트 설정 저장 및 결과 편집 UI
- APK 빌드 및 실기기 테스트

## API 참고
OpenAI Chat Completions API: https://developers.openai.com/api/reference/resources/chat/subresources/completions/methods/create
OpenAI API 키 보안 지침: https://developers.openai.com/api/reference/overview

## 빌드
Android Studio에서 프로젝트를 열고 Gradle Sync 후 Build > Build Bundle(s) / APK(s) > Build APK(s).
현재 작업 환경에는 Android SDK/Gradle이 없어 APK를 직접 생성하지 못했습니다.


## 개발 단계 0.8 — 사진 자동 10MB 압축
- 원본 이미지는 최대 50MB까지 임시 다운로드
- 10MB 이하인 JPEG는 원본 그대로 보관
- 10MB 초과 이미지는 앱 내부에서 JPEG로 변환·압축
- 품질을 단계적으로 낮춘 뒤 필요하면 해상도를 줄여 10MB 이하로 저장
- 앱 내부 저장 파일은 10MB 초과 시 보관하지 않음
- PNG/WebP/GIF는 JPEG로 변환될 수 있으며, GIF 애니메이션 및 투명 배경은 유지되지 않음
- 원본은 임시 캐시에만 저장 후 삭제


## 개발 단계 0.9 — PRESSQ CMS 로그인 자동입력 기반
- 앱 내 CMS 로그인 정보 설정 화면 추가
- 아이디/비밀번호를 Android Keystore 기반 AES-GCM으로 암호화해 기기에 저장
- `https://admin.pressq.kr`을 앱 내 WebView로 열기
- 로그인 화면의 아이디/비밀번호 필드를 찾아 자동 입력
- '자동 로그인' 체크박스 자동 선택 시도
- 보안상 로그인 버튼은 자동으로 누르지 않음. 사용자가 화면에서 로그인 결과를 확인
- CMS의 실제 로그인 성공, 글쓰기 화면 및 임시저장 동작은 실기기·계정 테스트 전까지 미검증


## 개발 단계 1.0 — OpenAI API 키 암호화 저장
- AI 초안 설정에서 OpenAI API 키를 선택적으로 기기에 저장
- AES-GCM 암호문은 앱 비공개 SharedPreferences에 저장하고 키는 Android Keystore로 보호
- 저장 해제 시 암호문과 Keystore 키 삭제
- API 키는 코드·로그·프로젝트 ZIP에 포함하지 않음
- 한계: 모바일 클라이언트 직접 호출은 OpenAI의 공식 권장 보안 방식이 아님. 기기 내 암호화는 정적 파일 노출을 줄일 뿐, 루팅·디버깅·앱 변조·실행 중 메모리 노출을 막지 못함
- 권장: PRESSQ 전용 Project API key, 만료일, 가능한 최소 권한, 사용량 알림 및 하드 한도 설정, 키 유출 의심 시 즉시 폐기·재발급


## 개발 단계 1.1 — GPT-6 Luna 기본 모델 및 비용 표시
- AI 초안 작성 화면의 기본 모델을 `gpt-6-luna`로 변경
- Chat Completions 응답의 입력/출력 토큰 사용량을 읽어 표시
- 알려진 모델의 표준 토큰 요금으로 요청별 예상 API 비용(USD)을 계산해 표시
- 비용은 모델 요금표 변경, 할인/처리 모드, 캐시 적용 등에 따라 실제 청구액과 차이가 날 수 있음
- 모델별 요금 상수는 OpenAI 공식 가격표를 확인해 주기적으로 갱신해야 함


## 개발 단계 1.2 — Gemini 무료 등급 + OpenAI 선택형 AI 엔진
- AI 기사 작성 화면에서 Gemini 무료 / OpenAI 유료 제공자 선택
- Gemini 기본 모델: `gemini-3.8-flash`
- Gemini REST `generateContent` 직접 호출 및 `usageMetadata` 토큰 수집
- OpenAI GPT-6 Luna 경로는 기존대로 유지
- Gemini API 키도 Android Keystore의 AES-GCM 키로 암호화해 기기 내부에 선택 저장
- Gemini 무료 등급은 사용량 제한이 있으며, Google 정책상 무료 등급 입력 데이터가 제품 개선에 사용될 수 있으므로 민감한 취재자료 입력 금지 안내 표시
- Gemini 무료 한도 초과 시 자동으로 유료 OpenAI로 전환하지 않음. 사용자가 제공자를 직접 선택해야 과금 전환을 통제할 수 있음
- 실제 API 호출, 모델 접근 권한, 무료 등급 할당량은 사용자 Google 계정·프로젝트 및 지역에 따라 확인 필요
- Android 빌드 및 Galaxy 기기 실기 테스트는 아직 수행하지 않음


## GitHub Actions APK 빌드 (휴대폰에서 진행)

이 프로젝트에는 Gradle Wrapper가 포함되어 있지 않으므로 GitHub Actions에서 Gradle 8.9와 JDK 17을 준비해 빌드하도록 `.github/workflows/android-apk.yml`을 추가했습니다.

1. GitHub에서 빈 저장소를 만들고 이 프로젝트 폴더 안의 파일과 폴더를 저장소 최상위에 업로드합니다. ZIP 파일 자체를 저장소에 올리는 것이 아니라 압축을 푼 **내용물**을 올려야 합니다.
2. 저장소의 `Actions` 탭에서 `Build PRESSQ NEWSROOM APK`를 선택합니다.
3. `Run workflow`를 누릅니다.
4. 작업이 초록색 완료 표시로 끝나면 실행 결과 아래 `Artifacts`에서 `PRESSQ-NEWSROOM-debug-apk`를 내려받습니다.
5. 내려받은 아티팩트 ZIP을 풀고 `app-debug.apk`를 갤럭시에 설치합니다.

빌드 성공은 컴파일 성공을 뜻할 뿐, 실제 수집 사이트 파싱·Gemini API·CMS 자동 임시저장 기능까지 검증됐다는 뜻은 아닙니다. 설치 후 각 기능을 별도로 시험해야 합니다.
